"""Models for facial keypoint detection"""

import torch
import torch.nn as nn
import torch.nn.functional as F

class KeypointModel(nn.Module):
    """Facial keypoint detection model"""
    def __init__(self, hparams):
        super().__init__()
        self.hparams = hparams

        self.conv1 = nn.Conv2d(hparams['input_channels'], hparams['conv1_channels'], kernel_size=3, stride=1, padding=1)
        self.conv2 = nn.Conv2d(hparams['conv1_channels'], hparams['conv2_channels'], kernel_size=3, stride=1, padding=1)
        self.conv3 = nn.Conv2d(hparams['conv2_channels'], hparams['conv3_channels'], kernel_size=3, stride=1, padding=1)


        self.pool = nn.MaxPool2d(kernel_size=2, stride=2, padding=0)

        self.fc1 = nn.Linear(hparams['conv3_channels'] * 12 * 12, hparams['fc1_size'])
        self.fc2 = nn.Linear(hparams['fc1_size'], hparams['output_size'])

        self.dropout = nn.Dropout(hparams['dropout_prob'])

    def forward(self, x):
        x = self.pool(F.relu(self.conv1(x)))
        x = self.pool(F.relu(self.conv2(x)))
        x = self.pool(F.relu(self.conv3(x)))

        x = x.view(-1, 128 * 12 * 12)

        x = F.relu(self.fc1(x))
        x = self.dropout(x)
        x = self.fc2(x)

        return x


class DummyKeypointModel(nn.Module):
    """Dummy model always predicting the keypoints of the first train sample"""
    def __init__(self):
        super().__init__()
        self.prediction = torch.tensor([[
            0.4685, -0.2319,
            -0.4253, -0.1953,
            0.2908, -0.2214,
            0.5992, -0.2214,
            -0.2685, -0.2109,
            -0.5873, -0.1900,
            0.1967, -0.3827,
            0.7656, -0.4295,
            -0.2035, -0.3758,
            -0.7389, -0.3573,
            0.0086, 0.2333,
            0.4163, 0.6620,
            -0.3521, 0.6985,
            0.0138, 0.6045,
            0.0190, 0.9076,
        ]])

    def forward(self, x):
        return self.prediction.repeat(x.size()[0], 1, 1, 1)
