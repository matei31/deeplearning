import torch
import torch.nn as nn
import numpy as np
import torch.optim as optim

class Encoder(nn.Module):

    def __init__(self, hparams, input_size=28 * 28, latent_dim=20):
        super().__init__()

        # set hyperparams
        self.latent_dim = latent_dim 
        self.input_size = input_size
        self.hparams = hparams
                # Initialize your encoder using nn.Sequential
        self.encoder = nn.Sequential(
            nn.Linear(input_size, 128),
            nn.ReLU(),
            nn.Linear(128, latent_dim)
        )

    def forward(self, x):
        # feed x into encoder!
        return self.encoder(x)

class Decoder(nn.Module):

    def __init__(self, hparams, latent_dim=20, output_size=28 * 28):
        super().__init__()

        # set hyperparams
        self.hparams = hparams

        # Initialize your decoder using nn.Sequential
        self.decoder = nn.Sequential(
            nn.Linear(latent_dim, 128),  # Adjust the input and output size as needed
            nn.ReLU(),
            nn.Linear(128, output_size),  # Adjust the output size to match the input size of your data# Assuming you want the output in the range [0, 1]
        )


    def forward(self, x):
        # feed x into decoder!
        return self.decoder(x)


class Autoencoder(nn.Module):

    def __init__(self, hparams, encoder, decoder):
        super().__init__()

        # set hyperparams
        self.hparams = hparams

        # Define models
        self.encoder = encoder
        self.decoder = decoder
        self.device = hparams.get("device", torch.device("cuda" if torch.cuda.is_available() else "cpu"))
        self.set_optimizer()

    def forward(self, x):
        reconstruction = self.decoder(self.encoder(x))
        return reconstruction

    def set_optimizer(self):
        # Define your optimizer for the autoencoder
        lr = self.hparams.get("learning_rate", 0.001)
        self.optimizer = torch.optim.Adam(self.parameters(), lr=lr)

    def training_step(self, batch, loss_func):
        # Training step for autoencoder
        self.train()  # Set the model to training mode
        self.optimizer.zero_grad()  # Reset the gradients
        images = batch.to(self.device)  # Move the data to the device
        flattened_images = images.view(images.shape[0], -1)  # Reshape the input for fully connected layers
        reconstruction = self.forward(flattened_images)  # Forward pass
        loss = loss_func(reconstruction, flattened_images)  # Compute the loss
        loss.backward()  # Backward pass
        self.optimizer.step()  # Update the parameters
        return loss

    def validation_step(self, batch, loss_func):
        # Validation step for autoencoder
        self.eval()  # Set the model to evaluation mode
        with torch.no_grad():
            images = batch.to(self.device)
            flattened_images = images.view(images.shape[0], -1)
            reconstruction = self.forward(flattened_images)
            loss = loss_func(reconstruction, flattened_images)
        return loss

    def getReconstructions(self, loader=None):
        # Get reconstructions for a given dataloader
        assert loader is not None, "Please provide a dataloader for reconstruction"
        self.eval()
        self = self.to(self.device)

        reconstructions = []

        for batch in loader:
            X = batch
            X = X.to(self.device)
            flattened_X = X.view(X.shape[0], -1)
            reconstruction = self.forward(flattened_X)
            reconstructions.append(
                reconstruction.view(-1, 28, 28).cpu().detach().numpy())

        return np.concatenate(reconstructions, axis=0)


class Classifier(nn.Module):

    def __init__(self, hparams, encoder):
        super().__init__()

        # set hyperparams
        self.hparams = hparams
        self.encoder = encoder

        # Classifier block
        self.model = nn.Sequential(
            nn.Linear(encoder.latent_dim, 128),  # Adjust the input and output size as needed
            nn.ReLU(),
            nn.Linear(128, hparams["num_classes"])  # Adjust the output size to match the number of classes
        )

        self.device = hparams.get("device", torch.device("cuda" if torch.cuda.is_available() else "cpu"))
        self.set_optimizer()
        
    def forward(self, x):
        x = self.encoder(x)
        x = self.model(x)
        return x

    def set_optimizer(self):
        
        lr = self.hparams.get("learning_rate", 0.001)
        self.optimizer = torch.optim.Adam(self.parameters(), lr=lr)

    def getAcc(self, loader=None):
        
        assert loader is not None, "Please provide a dataloader for accuracy evaluation"

        self.eval()
        self = self.to(self.device)
            
        scores = []
        labels = []

        for batch in loader:
            X, y = batch
            X = X.to(self.device)
            flattened_X = X.view(X.shape[0], -1)
            score = self.forward(flattened_X)
            scores.append(score.detach().cpu().numpy())
            labels.append(y.detach().cpu().numpy())

        scores = np.concatenate(scores, axis=0)
        labels = np.concatenate(labels, axis=0)

        preds = scores.argmax(axis=1)
        acc = (labels == preds).mean()
        return preds, acc
