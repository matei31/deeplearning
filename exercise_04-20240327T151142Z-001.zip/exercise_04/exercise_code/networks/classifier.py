
import os
import pickle
import numpy as np

from exercise_code.networks.base_networks import Network


class Classifier(Network):
    """
    Classifier of the form y = sigmoid(X * W)
    """

    def __init__(self, num_features=2):
        super().__init__("classifier")

        self.num_features = num_features 
        self.W = None
        self.cache = None

    def initialize_weights(self, weights=None):
        """
        Initialize the weight matrix W

        :param weights: optional weights for initialization
        """
        if weights is not None:
            assert weights.shape == (self.num_features + 1, 1), \
                "weights for initialization are not in the correct shape (num_features + 1, 1)"
            self.W = weights
        else:
            self.W = 0.001 * np.random.randn(self.num_features + 1, 1)
        self.cache = None

    def forward(self, X):
        assert self.W is not None, "weight matrix W is not initialized"
        # add a column of 1s to the data for the bias term
        batch_size, _ = X.shape
        X = np.concatenate((X, np.ones((batch_size, 1))), axis=1)
        
        z = self.sigmoid(X @ self.W) 

        self.cache = (X, z)

        return z

    def backward(self, dout):
        assert self.cache is not None, "Run a forward pass before the backward pass. Also, don't forget to store the relevant variables\
            such as in 'self.cache = (X, y, ...)"
        
        X, z = self.cache

        dz = dout * z * (1 - z)
        dW = X.T @ dz 

        self.cache = (X, dz)

        return dW

    def sigmoid(self, x):
        return 1 / (1 + np.exp(-x))

    def save_model(self):
        directory = 'models'
        model = {self.model_name: self}
        if not os.path.exists(directory):
            os.makedirs(directory)
        pickle.dump(
            model,
            open(
                directory +
                '/' +
                self.model_name +
                '.p',
                'wb'))
